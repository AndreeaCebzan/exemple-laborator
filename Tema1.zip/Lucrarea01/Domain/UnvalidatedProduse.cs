﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Lucrarea01
{
    public record UnvalidatedProduse(string ProdusID, string ProdusCantitate);

}