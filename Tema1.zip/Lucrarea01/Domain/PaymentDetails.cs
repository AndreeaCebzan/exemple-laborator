﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Lucrarea01
{
    public record PaymentDetails(string PaymentAddress, int PaymentState) { }
}